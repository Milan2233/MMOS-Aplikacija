package com.example.rastovicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private TextView xTextView, yTextView, zTextView;
    private SensorManager sensorManager;
    private Sensor mGravity;
    private boolean isGravitySensorPresent;
    private AudioManager audioManager;

    ImageButton imageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    imageButton = (ImageButton)findViewById(R.id.imageButton);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                imageButton.animate().rotation(imageButton.getRotation()-360).start();
            }
        });



        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        xTextView = findViewById(R.id.xTextView);
        yTextView = findViewById(R.id.yTextView);
        zTextView = findViewById(R.id.zTextView);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        if(sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)!=null)
        {
            mGravity = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
            isGravitySensorPresent = true;
        }else {
            xTextView.setText("Ne postoji");
            isGravitySensorPresent = false;
        }

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        xTextView.setText(sensorEvent.values[0]+ "m/s2");
        yTextView.setText(sensorEvent.values[1]+ "m/s2");
        zTextView.setText(sensorEvent.values[0]+ "m/s2");

        if(sensorEvent.values[2]<-9.7)
        {
            getWindow().getDecorView().setBackgroundColor(Color.GREEN);
            audioManager.setRingerMode(audioManager.RINGER_MODE_VIBRATE);
        }else {
            getWindow().getDecorView().setBackgroundColor(Color.BLACK);
            audioManager.setRingerMode(audioManager.RINGER_MODE_NORMAL);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        if(sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)!=null)
        {
            sensorManager.registerListener(this,mGravity,SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)!=null)
        {
            sensorManager.unregisterListener(this,mGravity);
        }
    }


}